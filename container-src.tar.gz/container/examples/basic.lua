#!/usr/sbin/container

filesystem["/root/"] = { type="map", path="root" }
